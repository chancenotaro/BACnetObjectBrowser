﻿namespace BACnetBrowser
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDiscoverDevices = new System.Windows.Forms.Button();
            this.treeViewDevices = new System.Windows.Forms.TreeView();
            this.dataGridViewProperties = new System.Windows.Forms.DataGridView();
            this.colObjectId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOjectName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPresentValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnReadProperty = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProperties)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDiscoverDevices
            // 
            this.btnDiscoverDevices.Location = new System.Drawing.Point(30, 36);
            this.btnDiscoverDevices.Name = "btnDiscoverDevices";
            this.btnDiscoverDevices.Size = new System.Drawing.Size(164, 23);
            this.btnDiscoverDevices.TabIndex = 0;
            this.btnDiscoverDevices.Text = "Discover Devices";
            this.btnDiscoverDevices.UseVisualStyleBackColor = true;
            this.btnDiscoverDevices.Click += new System.EventHandler(this.btnDiscoverDevices_Click);
            // 
            // treeViewDevices
            // 
            this.treeViewDevices.Location = new System.Drawing.Point(30, 65);
            this.treeViewDevices.Name = "treeViewDevices";
            this.treeViewDevices.Size = new System.Drawing.Size(324, 227);
            this.treeViewDevices.TabIndex = 1;
            // 
            // dataGridViewProperties
            // 
            this.dataGridViewProperties.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProperties.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colObjectId,
            this.colOjectName,
            this.colPresentValue});
            this.dataGridViewProperties.Location = new System.Drawing.Point(378, 65);
            this.dataGridViewProperties.Name = "dataGridViewProperties";
            this.dataGridViewProperties.Size = new System.Drawing.Size(401, 227);
            this.dataGridViewProperties.TabIndex = 2;
            // 
            // colObjectId
            // 
            this.colObjectId.HeaderText = "Object ID";
            this.colObjectId.Name = "colObjectId";
            // 
            // colOjectName
            // 
            this.colOjectName.HeaderText = "Object Name";
            this.colOjectName.Name = "colOjectName";
            // 
            // colPresentValue
            // 
            this.colPresentValue.HeaderText = "Present Value";
            this.colPresentValue.Name = "colPresentValue";
            // 
            // btnReadProperty
            // 
            this.btnReadProperty.Location = new System.Drawing.Point(201, 36);
            this.btnReadProperty.Name = "btnReadProperty";
            this.btnReadProperty.Size = new System.Drawing.Size(141, 23);
            this.btnReadProperty.TabIndex = 3;
            this.btnReadProperty.Text = "Read Property";
            this.btnReadProperty.UseVisualStyleBackColor = true;
            this.btnReadProperty.Click += new System.EventHandler(this.btnReadProperty_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnReadProperty);
            this.Controls.Add(this.dataGridViewProperties);
            this.Controls.Add(this.treeViewDevices);
            this.Controls.Add(this.btnDiscoverDevices);
            this.Name = "MainForm";
            this.Text = "BACnet Object Browser";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProperties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnDiscoverDevices;
        private System.Windows.Forms.TreeView treeViewDevices;
        private System.Windows.Forms.DataGridView dataGridViewProperties;
        private System.Windows.Forms.DataGridViewTextBoxColumn colObjectId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOjectName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPresentValue;
        private System.Windows.Forms.Button btnReadProperty;
    }
}

