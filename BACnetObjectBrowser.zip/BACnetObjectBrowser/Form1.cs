﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO.BACnet;

namespace BACnetBrowser
{
    public partial class MainForm : Form
    {
        private BacnetClient bacnetClient; // BACnet client for communication

        public MainForm()
        {
            InitializeComponent();

            // Initialize the BACnet client
            bacnetClient = new BacnetClient(new BacnetIpUdpProtocolTransport(47808));
            bacnetClient.OnIam += OnIamHandler;

            // Start the BACnet client
            bacnetClient.Start();
        }

        private void btnDiscoverDevices_Click(object sender, EventArgs e)
        {
            // Broadcast "Who-Is" request on the network
            bacnetClient.WhoIs();
        }

        // Event handler for IAM response
        private void OnIamHandler(BacnetClient sender, BacnetAddress address, uint deviceId, uint maxApdu, BacnetSegmentations segmentation, ushort vendorId)
        {
            // Display device information
            string deviceInfo = $"Device ID: {deviceId}, Address: {address}";
            MessageBox.Show(deviceInfo, "Device Found");

            // Optionally, add device to a list or tree view for further exploration
        }

        private void btnReadProperty_Click(object sender, EventArgs e)
        {
            // Sample to read a property, e.g., present-value of analog input object
            BacnetAddress deviceAddress = new BacnetAddress(BacnetAddressTypes.IP, "192.168.1.1"); // Example address
            uint deviceId = 12345; // Replace with actual device ID
            BacnetObjectId objectId = new BacnetObjectId(BacnetObjectTypes.OBJECT_ANALOG_INPUT, 0); // Adjust as needed

            try
            {
                // Reading a property
                IList<BacnetValue> valueList;
                bool success = bacnetClient.ReadPropertyRequest(deviceAddress, objectId, BacnetPropertyIds.PROP_PRESENT_VALUE, out valueList);

                if (success)
                {
                    foreach (var value in valueList)
                    {
                        MessageBox.Show($"Value: {value.Value}", "Property Read");
                    }
                }
                else
                {
                    MessageBox.Show("Failed to read property", "Error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error reading property: {ex.Message}");
            }
        }
    }
}

